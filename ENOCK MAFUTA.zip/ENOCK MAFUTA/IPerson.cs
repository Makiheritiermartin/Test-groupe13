﻿using System;

namespace InterfaceUsage
{
    public interface IPerson
    {
        void visualiserIdentite();
        void visualiserdonnesIdentite(int id);
        int Ajouter();
    }
}
