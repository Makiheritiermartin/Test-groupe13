/**
 * 
 */
/**
 * @author Josamuna
 *
 */
module singletonJava {
	requires java.sql;
}