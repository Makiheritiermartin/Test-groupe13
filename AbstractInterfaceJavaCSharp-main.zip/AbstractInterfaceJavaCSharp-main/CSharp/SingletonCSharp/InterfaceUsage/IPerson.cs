﻿using System;

namespace InterfaceUsage
{
    public interface IPerson
    {
        void ShowIdentity();
        void ShowDynamicIdentity(int id);
        int Add();
    }
}
