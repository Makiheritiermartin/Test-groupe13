﻿using System;

namespace SingletonLibrary
{
    public enum ConnectionType
    {
        MYSQL_CONNECTION,
        SQL_SERVER_CONNECTION
    }
}
